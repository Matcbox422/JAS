﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Smarthub.Models
{
    public class OrderLine
    {
        public int Id { get; set; }

        public int OrderId { get; set; }

        [Display(Name = "Line Number")]
        public int LineNumber { get; set; }

        [Required]
        [Display(Name = "Product Code")]
        public string ProductCode { get; set; }

        [Required]
        [Display(Name = "Product Type")]
        public string ProductType { get; set; }

        [Required]
        [Display(Name = "Product Cost Price")]
        public decimal ProductCostPrice { get; set; }

        [Required]
        [Display(Name = "Product Sales Price")]
        public decimal ProductSalesPrice { get; set; }

        [Required]
        [Display(Name = "Quantity")]
        public int Quantity { get; set; }
    }
}
