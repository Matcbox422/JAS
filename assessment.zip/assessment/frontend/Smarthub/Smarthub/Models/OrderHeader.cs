﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Smarthub.Models
{
    public class OrderHeader
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Order Number")]
        public string OrderNumber { get; set; }

        [Required]
        [Display(Name = "Order Type")]
        public string OrderType { get; set; }

        [Required]
        [Display(Name = "Order Status")]
        public string OrderStatus { get; set; }

        [Required]
        [Display(Name = "Customer Name")]
        public string CustomerName { get; set; }

        [Required]
        [Display(Name = "Order Date and Time")]
        public DateTime OrderDateTime { get; set; }

        [Display(Name = "Order Created Date and Time")]
        public DateTime OrderCreatedDateTime { get; set; } = DateTime.Now;
    }
}
