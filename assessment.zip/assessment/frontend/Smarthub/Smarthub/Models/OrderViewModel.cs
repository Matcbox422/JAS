﻿namespace Smarthub.Models
{
    public class OrderViewModel
    {
        public OrderHeader OrderHeader { get; set; }
        public OrderLine OrderLine { get; set; }
    }
}
