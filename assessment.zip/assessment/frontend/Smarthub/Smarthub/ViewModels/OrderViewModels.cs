﻿using Smarthub.Models;

namespace Smarthub.ViewModels
{
    public class OrderViewModels
    {
        public List<OrderHeader> OrderHeaders { get; set; }
        public List<OrderLine> OrderLines { get; set; }
    }
}
