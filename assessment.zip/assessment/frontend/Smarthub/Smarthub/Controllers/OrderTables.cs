﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Smarthub.Models;
using Smarthub.ViewModels;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace Smarthub.Controllers
{
    public class OrderTablesController : Controller
    {
        private readonly ILogger<OrderTablesController> _logger;
        private readonly IHttpClientFactory _clientFactory;
        private readonly IConfiguration _configuration;

        public OrderTablesController(ILogger<OrderTablesController> logger, IHttpClientFactory clientFactory, IConfiguration configuration)
        {
            _logger = logger;
            _clientFactory = clientFactory;
            _configuration = configuration;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                var orderHeaders = await GetOrderHeaders();
                var orderLines = await GetOrderLines();

                var viewModel = new OrderViewModels
                {
                    OrderHeaders = orderHeaders,
                    OrderLines = orderLines
                };

                return View(viewModel);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while fetching order data from API.");
                return RedirectToAction("Error", "Home");
            }
        }

        // In your controller action method
        private async Task<List<OrderHeader>> GetOrderHeaders()
        {
            try
            {
                var baseUrl = _configuration["ApiSettings:BaseUrl"];
                var client = _clientFactory.CreateClient();
                var response = await client.GetAsync($"{baseUrl}/api/OrderHeader");

                response.EnsureSuccessStatusCode();

                var responseBody = await response.Content.ReadAsStringAsync();
                var orderHeaders = JsonConvert.DeserializeObject<List<OrderHeader>>(responseBody);

                return orderHeaders;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while fetching order headers from API.");
                throw;
            }
        }

        private async Task<List<OrderLine>> GetOrderLines()
        {
            try
            {
                var baseUrl = _configuration["ApiSettings:BaseUrl"];
                var client = _clientFactory.CreateClient();
                var response = await client.GetAsync($"{baseUrl}/api/OrderLine");

                response.EnsureSuccessStatusCode();

                var responseBody = await response.Content.ReadAsStringAsync();
                var orderLines = JsonConvert.DeserializeObject<List<OrderLine>>(responseBody);

                return orderLines;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while fetching order lines from API.");
                throw;
            }
        }

        [HttpPost]
        public async Task<IActionResult> EditOrderHeader(OrderHeader orderHeader)
        {
            try
            {
                var baseUrl = _configuration["ApiSettings:BaseUrl"];
                var client = _clientFactory.CreateClient();
                var jsonOrderHeader = JsonConvert.SerializeObject(orderHeader);
                var content = new StringContent(jsonOrderHeader, System.Text.Encoding.UTF8, "application/json");
                var response = await client.PutAsync($"{baseUrl}/api/OrderHeader/{orderHeader.Id}", content);

                response.EnsureSuccessStatusCode();

                return RedirectToAction("Index"); // Redirect to the index page after editing
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while updating order header through API.");
                return RedirectToAction("Error", "Home");
            }
        }

        [HttpPost]
        public async Task<IActionResult> EditOrderLine(OrderLine orderLine)
        {
            try
            {
                var baseUrl = _configuration["ApiSettings:BaseUrl"];
                var client = _clientFactory.CreateClient();
                var jsonOrderLine = JsonConvert.SerializeObject(orderLine);
                var content = new StringContent(jsonOrderLine, System.Text.Encoding.UTF8, "application/json");
                var response = await client.PutAsync($"{baseUrl}/api/OrderLine/{orderLine.Id}", content);

                response.EnsureSuccessStatusCode();

                return RedirectToAction("Index"); // Redirect to the index page after editing
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while updating order line through API.");
                return RedirectToAction("Error", "Home");
            }
        }


        [HttpPost]
        public async Task<IActionResult> DeleteOrderHeader(int id)
        {
            try
            {
                var baseUrl = _configuration["ApiSettings:BaseUrl"];
                var client = _clientFactory.CreateClient();
                var response = await client.DeleteAsync($"{baseUrl}/api/OrderHeader/{id}");

                response.EnsureSuccessStatusCode();

                return RedirectToAction("Index"); // Redirect to the index page after deleting
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while deleting order header through API.");
                return RedirectToAction("Error", "Home");
            }
        }

        [HttpPost]
        public async Task<IActionResult> DeleteOrderLine(int id)
        {
            try
            {
                var baseUrl = _configuration["ApiSettings:BaseUrl"];
                var client = _clientFactory.CreateClient();
                var response = await client.DeleteAsync($"{baseUrl}/api/OrderLine/{id}");

                response.EnsureSuccessStatusCode();

                return NoContent(); // Return 204 No Content on successful deletion
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while deleting order line through API.");
                return StatusCode(500, "Error occurred while deleting order line through API.");
            }
        }

    }
}
