using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using Smarthub.Models;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Smarthub.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IHttpClientFactory _clientFactory;
        private readonly IConfiguration _configuration;

        public HomeController(ILogger<HomeController> logger, IHttpClientFactory clientFactory, IConfiguration configuration)
        {
            _logger = logger;
            _clientFactory = clientFactory;
            _configuration = configuration;
        }

        public IActionResult Index()
        {
            return View(new OrderHeader()); // Use OrderHeader model for the view
        }

        [HttpPost]
        public async Task<IActionResult> Index(OrderHeader order)
        {
            if (!ModelState.IsValid)
            {
                // If model state is not valid, return to the same view with validation errors
                return View(order);
            }

            try
            {
                var baseUrl = _configuration["ApiSettings:BaseUrl"]; // Get base URL from appsettings.json
                var client = _clientFactory.CreateClient();

                var jsonOrder = JsonSerializer.Serialize(order);
                var content = new StringContent(jsonOrder, Encoding.UTF8, "application/json");

                var response = await client.PostAsync($"{baseUrl}/api/OrderHeader", content);

                response.EnsureSuccessStatusCode();

                // Optionally, you can clear the form here
                ModelState.Clear();

                // Return the view without redirection
                return View();
            }
            catch (Exception ex)
            {
                // Handle exception if API request fails
                _logger.LogError(ex, "Error occurred while submitting order data to API.");
                return RedirectToAction("Error", "Home");
            }
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
