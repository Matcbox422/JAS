﻿using Microsoft.AspNetCore.Mvc;
using Smarthub.Models;
using System.Diagnostics;
using System.Text;
using System.Text.Json;

namespace Smarthub.Controllers
{
    public class OrderLineController : Controller
    {
        private readonly ILogger<OrderLineController> _logger;
        private readonly IHttpClientFactory _clientFactory;
        private readonly IConfiguration _configuration;

        public OrderLineController(ILogger<OrderLineController> logger, IHttpClientFactory clientFactory, IConfiguration configuration)
        {
            _logger = logger;
            _clientFactory = clientFactory;
            _configuration = configuration;
        }

        public IActionResult Index()
        {
            return View(new OrderLine());
        }

        // Order line post function
        [HttpPost]
        public async Task<IActionResult> CreateOrderLine(OrderLine orderLine)
        {
            if (!ModelState.IsValid)
            {
                // If model state is not valid, return bad request
                return BadRequest(ModelState);
            }

            try
            {
                var baseUrl = _configuration["ApiSettings:BaseUrl"]; // Get base URL from appsettings.json
                var client = _clientFactory.CreateClient();

                var jsonOrderLine = JsonSerializer.Serialize(orderLine);
                var content = new StringContent(jsonOrderLine, Encoding.UTF8, "application/json");

                var response = await client.PostAsync($"{baseUrl}/api/OrderLine", content);

                response.EnsureSuccessStatusCode();

                // Optionally, you can clear the form here
                ModelState.Clear();

                // Return no content
                return NoContent();
            }
            catch (Exception ex)
            {
                // Handle exception if API request fails
                _logger.LogError(ex, "Error occurred while submitting order line data to API.");
                return StatusCode(500, "Error occurred while submitting order line data to API.");
            }
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
