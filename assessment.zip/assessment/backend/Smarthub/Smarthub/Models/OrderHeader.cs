﻿namespace Smarthub.Models
{
    public class OrderHeader
    {
        public int Id { get; set; }
        public string OrderNumber { get; set; }
        public string OrderType { get; set; }
        public string OrderStatus { get; set; }
        public string CustomerName { get; set; }
        public DateTime OrderDateTime { get; set; }
        public DateTime OrderCreatedDateTime { get; set; }
    }
}
