﻿namespace Smarthub.Models
{
    public class OrderLine
    {
        public int Id { get; set; }
        public int OrderHeaderId { get; set; }
        public int LineNumber { get; set; }
        public string ProductCode { get; set; }
        public string ProductType { get; set; }
        public decimal ProductCostPrice { get; set; }
        public decimal ProductSalesPrice { get; set; }
        public int Quantity { get; set; }
    }
}
