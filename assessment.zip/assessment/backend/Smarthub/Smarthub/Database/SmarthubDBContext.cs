﻿using Smarthub.Models;
using Microsoft.EntityFrameworkCore;

namespace Smarthub.Database
{
    public class SmarthubDBContext : DbContext
    {
        public SmarthubDBContext(DbContextOptions<SmarthubDBContext> options) : base(options)
        {
        }

        public DbSet<OrderHeader> OrderHeaders { get; set; }
        public DbSet<OrderLine> OrderLines { get; set; }
    }
}
