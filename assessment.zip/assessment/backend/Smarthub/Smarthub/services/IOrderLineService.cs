﻿using System.Collections.Generic;
using Smarthub.Models;

namespace Smarthub.services
{
    public interface IOrderLineService
    {
        IEnumerable<OrderLine> GetAllOrderLines();
        OrderLine GetOrderLineById(int id);
        OrderLine CreateOrderLine(OrderLine orderLine);
        OrderLine UpdateOrderLine(OrderLine orderLine);
        bool DeleteOrderLine(int id);
    }
}
