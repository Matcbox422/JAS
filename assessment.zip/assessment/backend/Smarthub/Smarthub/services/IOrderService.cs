﻿using Smarthub.Models;
using System.Collections.Generic;

namespace Smarthub.services
{
    public interface IOrderService
    {
        IEnumerable<OrderHeader> GetAllOrderHeaders();
        OrderHeader GetOrderHeaderById(int id);
        OrderHeader CreateOrderHeader(OrderHeader orderHeader);
        OrderHeader UpdateOrderHeader(OrderHeader orderHeader);
        bool DeleteOrderHeader(int id);
    }
}
