﻿using Smarthub.Database;
using Smarthub.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Smarthub.services
{
    public class OrderService : IOrderService
    {
        private readonly SmarthubDBContext _dbContext;

        public OrderService(SmarthubDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IEnumerable<OrderHeader> GetAllOrderHeaders()
        {
            return _dbContext.OrderHeaders.ToList();
        }

        public OrderHeader GetOrderHeaderById(int id)
        {
            return _dbContext.OrderHeaders.FirstOrDefault(o => o.Id == id);
        }

        public OrderHeader CreateOrderHeader(OrderHeader orderHeader)
        {
            orderHeader.OrderCreatedDateTime = DateTime.Now;
            _dbContext.OrderHeaders.Add(orderHeader);
            _dbContext.SaveChanges();
            return orderHeader;
        }

        public OrderHeader UpdateOrderHeader(OrderHeader orderHeader)
        {
            var existingOrderHeader = _dbContext.OrderHeaders.Find(orderHeader.Id);
            if (existingOrderHeader == null)
            {
                return null;
            }

            existingOrderHeader.OrderNumber = orderHeader.OrderNumber;
            existingOrderHeader.OrderType = orderHeader.OrderType;
            existingOrderHeader.OrderStatus = orderHeader.OrderStatus;
            existingOrderHeader.CustomerName = orderHeader.CustomerName;
            existingOrderHeader.OrderDateTime = orderHeader.OrderDateTime;

            _dbContext.SaveChanges();
            return existingOrderHeader;
        }

        public bool DeleteOrderHeader(int id)
        {
            var orderHeader = _dbContext.OrderHeaders.Find(id);
            if (orderHeader == null)
            {
                return false;
            }

            _dbContext.OrderHeaders.Remove(orderHeader);
            _dbContext.SaveChanges();
            return true;
        }
    }
}
