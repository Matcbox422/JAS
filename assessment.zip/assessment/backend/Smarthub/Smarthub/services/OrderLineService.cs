﻿using Smarthub.Database;
using Smarthub.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Smarthub.services
{
    public class OrderLineService : IOrderLineService
    {
        private readonly SmarthubDBContext _dbContext;

        public OrderLineService(SmarthubDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IEnumerable<OrderLine> GetAllOrderLines()
        {
            return _dbContext.OrderLines.ToList();
        }

        public OrderLine GetOrderLineById(int id)
        {
            return _dbContext.OrderLines.FirstOrDefault(o => o.Id == id);
        }

        public OrderLine CreateOrderLine(OrderLine orderLine)
        {
            _dbContext.OrderLines.Add(orderLine);
            _dbContext.SaveChanges();
            return orderLine;
        }

        public OrderLine UpdateOrderLine(OrderLine orderLine)
        {
            var existingOrderLine = _dbContext.OrderLines.Find(orderLine.Id);
            if (existingOrderLine == null)
            {
                return null;
            }

            // Update existing order line properties
            existingOrderLine.ProductCode = orderLine.ProductCode;
            existingOrderLine.ProductType = orderLine.ProductType;
            existingOrderLine.ProductCostPrice = orderLine.ProductCostPrice;
            existingOrderLine.ProductSalesPrice = orderLine.ProductSalesPrice;
            existingOrderLine.Quantity = orderLine.Quantity;

            _dbContext.SaveChanges();
            return existingOrderLine;
        }

        public bool DeleteOrderLine(int id)
        {
            var orderLine = _dbContext.OrderLines.Find(id);
            if (orderLine == null)
            {
                return false;
            }

            _dbContext.OrderLines.Remove(orderLine);
            _dbContext.SaveChanges();
            return true;
        }
    }
}
