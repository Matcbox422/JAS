﻿using Microsoft.AspNetCore.Mvc;
using Smarthub.Models;
using Smarthub.services;
using System;
using System.Collections.Generic;

namespace Smarthub.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderHeaderController : ControllerBase
    {
        private readonly IOrderService _orderService;

        public OrderHeaderController(IOrderService orderService)
        {
            _orderService = orderService;
        }

        [HttpGet]
        public ActionResult<IEnumerable<OrderHeader>> GetAllOrderHeaders()
        {
            var orderHeaders = _orderService.GetAllOrderHeaders();
            return Ok(orderHeaders);
        }

        [HttpGet("{id}")]
        public ActionResult<OrderHeader> GetOrderHeader(int id)
        {
            var orderHeader = _orderService.GetOrderHeaderById(id);
            if (orderHeader == null)
            {
                return NotFound();
            }
            return Ok(orderHeader);
        }

        [HttpPost]
        public ActionResult<OrderHeader> CreateOrderHeader(OrderHeader orderHeader)
        {
            var createdOrderHeader = _orderService.CreateOrderHeader(orderHeader);
            return CreatedAtAction(nameof(GetOrderHeader), new { id = createdOrderHeader.Id }, createdOrderHeader);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateOrderHeader(int id, OrderHeader orderHeader)
        {
            if (id != orderHeader.Id)
            {
                return BadRequest();
            }
            var updatedOrderHeader = _orderService.UpdateOrderHeader(orderHeader);
            if (updatedOrderHeader == null)
            {
                return NotFound();
            }
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteOrderHeader(int id)
        {
            var isDeleted = _orderService.DeleteOrderHeader(id);
            if (!isDeleted)
            {
                return NotFound();
            }
            return NoContent();
        }
    }
}