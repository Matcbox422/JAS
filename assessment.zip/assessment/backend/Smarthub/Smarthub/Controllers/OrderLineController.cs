﻿using Microsoft.AspNetCore.Mvc;
using Smarthub.Models;
using Smarthub.services;
using System.Collections.Generic;

namespace Smarthub.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderLineController : ControllerBase
    {
        private readonly IOrderLineService _orderLineService;

        public OrderLineController(IOrderLineService orderLineService)
        {
            _orderLineService = orderLineService;
        }

        [HttpGet]
        public ActionResult<IEnumerable<OrderLine>> GetAllOrderLines()
        {
            var orderLines = _orderLineService.GetAllOrderLines();
            return Ok(orderLines);
        }

        [HttpGet("{id}")]
        public ActionResult<OrderLine> GetOrderLine(int id)
        {
            var orderLine = _orderLineService.GetOrderLineById(id);
            if (orderLine == null)
            {
                return NotFound();
            }
            return Ok(orderLine);
        }

        [HttpPost]
        public ActionResult<OrderLine> CreateOrderLine(OrderLine orderLine)
        {
            var createdOrderLine = _orderLineService.CreateOrderLine(orderLine);
            return CreatedAtAction(nameof(GetOrderLine), new { id = createdOrderLine.Id }, createdOrderLine);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateOrderLine(int id, OrderLine orderLine)
        {
            if (id != orderLine.Id)
            {
                return BadRequest();
            }
            var updatedOrderLine = _orderLineService.UpdateOrderLine(orderLine);
            if (updatedOrderLine == null)
            {
                return NotFound();
            }
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteOrderLine(int id)
        {
            var isDeleted = _orderLineService.DeleteOrderLine(id);
            if (!isDeleted)
            {
                return NotFound();
            }
            return NoContent();
        }
    }
}